package prueba.dev.sps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnitVsIntApplicationTests {

	@Test
	void contextLoads() {
	}

}
